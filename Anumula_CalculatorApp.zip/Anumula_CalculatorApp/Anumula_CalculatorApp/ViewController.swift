//
//  ViewController.swift
//  Anumula_CalculatorApp
//
//  Created by Anumula,Anjith Kumar on 2/11/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultOutlet: UILabel!
    var operations:String = ""
    var operand1:String = ""
    var operand2:String = ""
    var calcOperator:String = ""
    var result:Int = 0
    var result2:Double = 0.0
    
    @IBAction func buttonAllClear(_ sender: Any) {
        clearAll()
    }
    
    @IBAction func buttonBackSpace(_ sender: Any) {
        if(!operations.isEmpty)
        {
            operations.removeLast()
            resultOutlet.text=operations
            if(operand1 != "" && calcOperator != "" && operand2 != ""){
                operand2.removeLast()
               
            }else if(operand1 != "" && calcOperator == "" && operand1 != ""){
                operand1.removeLast()
            }
            if(operations == ""){
                clearAll()
            }
        }else{
            clearAll()
        }
    }
    
    @IBAction func buttonPlusorMinus(_ sender: Any) {
        addToOperations(value: "(+/-)")
        if(calcOperator != "") {
            if(calcOperator == "+"){
                calcOperator = "-"
            }else if(calcOperator == "-"){
                calcOperator = "+"
            }
        }
    }
    @IBAction func buttonDivide(_ sender: Any) {
        addToOperations(value: "÷")
        calcOperator = "÷"
    }
    
    @IBAction func buttonSeven(_ sender: Any) {
        addToOperations(value: "7")
        if(calcOperator==""){
            operand1 = operand1+"7"
        }
        else{
            operand2 = operand2+"7"
        }
    }
    
    @IBAction func buttonEight(_ sender: Any) {
        addToOperations(value: "8")
        if(calcOperator==""){
            operand1 = operand1+"8"
        }
        else{
            operand2 = operand2+"8"
        }
    }
    
    @IBAction func buttonNine(_ sender: Any) {
        addToOperations(value: "9")
        if(calcOperator==""){
            operand1 = operand1+"9"
        }
        else{
            operand2 = operand2+"9"
        }
    }
    @IBAction func buttonFour(_ sender: Any) {
        addToOperations(value: "4")
        if(calcOperator==""){
            operand1 = operand1+"4"
        }
        else{
            operand2 = operand2+"4"
        }
        
    }
    @IBAction func buttonFive(_ sender: Any) {
        addToOperations(value: "5")
        if(calcOperator==""){
            operand1 = operand1+"5"
        }
        else{
            operand2 = operand2+"5"
        }
    }
    @IBAction func buttonSix(_ sender: Any) {
        addToOperations(value: "6")
        if(calcOperator==""){
            operand1 = operand1+"6"
        }
        else{
            operand2 = operand2+"6"
        }
    }
    @IBAction func buttonOne(_ sender: Any) {
        addToOperations(value: "1")
        if(calcOperator==""){
            operand1 = operand1+"1"
        }
        else{
            operand2 = operand2+"1"
        }
    }
    @IBAction func buttonTwo(_ sender: Any) {
        addToOperations(value: "2")
        if(calcOperator==""){
            operand1 = operand1+"2"
        }
        else{
            operand2 = operand2+"2"
        }
    }
    @IBAction func buttonThree(_ sender: Any) {
        addToOperations(value: "3")
        if(calcOperator==""){
            operand1 = operand1+"3"
        }
        else{
            operand2 = operand2+"3"
        }
    }
    
    @IBAction func buttonMultiply(_ sender: Any) {
        addToOperations(value: "x")
        calcOperator = "x"
    }
    @IBAction func buttonMinus(_ sender: Any) {
        addToOperations(value: "-")
        calcOperator = "-"
    }
    @IBAction func buttonPlus(_ sender: Any) {
        addToOperations(value: "+")
        calcOperator = "+"
    }
    
    @IBAction func buttonPoint(_ sender: Any) {
        addToOperations(value: ".")
        if(operand2 != "")
        {
            operand2=operand2+"."
        }else{
            operand1 = operand1+"."
        }
    }
    @IBAction func buttonPercentage(_ sender: Any) {
        addToOperations(value: "%")
        calcOperator = "%"
    }
   
    @IBAction func buttonZero(_ sender: Any) {
        addToOperations(value:"0")
        if(calcOperator==""){
            operand1 = operand1+"0"
        }
        else{
            operand2 = operand2+"0"
        }

    }
    
    
    @IBAction func buttonEqual(_ sender: Any) {
        addToOperations(value: "=")
        if(operations.contains(".")){
            var op1 = Double(operand1) ?? 0.0
            var op2 = Double(operand2) ?? 0.0
            if(calcOperator == "+"){
                result2 = op1+op2
            }else if(calcOperator == "x"){
                result2 = op1*op2
            }else if(calcOperator == "-"){
                result2 = op1-op2
            }else if(calcOperator == "÷")
            {
                if(op2 != 0.0){
                    result2 = op1/op2
                }else{
                    addToOperations(value: "Not Possible")
                }
            }else if(calcOperator == "%"){
                if(op2 != 0.0){
                    result2 = op1.truncatingRemainder(dividingBy: op2)
                }else{
                    addToOperations(value: "Not a number")
                }
            }
            if(result2 == result2.rounded()){
                addToOperations(value: String(Int(result2)))
            }
            else{
                if(calcOperator == "%"){
                    addToOperations(value: String(format: "%.1f", result2))
                }else{
                    addToOperations(value: String(format: "%.5f", result2))
                }
            }
        }else{
            var op1 = Int(operand1) ?? 0
            var op2 = Int(operand2) ?? 0
            if(calcOperator == "+"){
                result = op1+op2
                addToOperations(value: String(result))
            }else if(calcOperator == "x"){
                result = op1*op2
                addToOperations(value: String(result))
            }else if(calcOperator == "-"){
                result = op1-op2
                addToOperations(value: String(result))
            }else if(calcOperator == "÷")
            {
                if(op2 != 0){
                    result2 = Double(op1)/Double(op2)
                    addToOperations(value: String(format: "%.5f", result2))
                }else{
                    addToOperations(value: "Not a number")
                }
            }else if(calcOperator == "%"){
                result = op1%op2
                addToOperations(value: String(result))
            }
            
        }
        
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        clearAll()
    }

    func addToOperations(value: String)
        {
            operations = operations + value
            resultOutlet.text = operations
        }
    func clearAll()
        {
            operations = ""
            resultOutlet.text = ""
            operand1 = ""
            operand2 = ""
            calcOperator = ""
            result = 0
        }
    
}

